#!/bin/bash
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python non trovato. Installalo da https://python.org/downloads e riapri questo file."
  read -p "Premi Invio per chiudere"
  exit 1
fi
echo "SLAW si apre su http://localhost:8000  (chiudi questa finestra per fermarlo)"
( sleep 1; open http://localhost:8000 ) >/dev/null 2>&1 &
python3 server.py
