# SLAW — versione sul tuo computer

1. Installa Python (python.org; su Windows spunta "Add Python to PATH").
2. Modalità Locale: installa Ollama (ollama.com) e scrivi `ollama pull llama3.2:1b`.
3. Doppio clic su "Avvia SLAW" (Windows: .bat, Mac: .command). Si apre http://localhost:8000.

Modalità Online: pulsante "Online" → "Chiave API" → incolla una chiave gratuita da console.groq.com/keys.
Voce e "Hey SLAW" (facoltativi): `pip install -r requirements-voce.txt` — funzionano sul computer che esegue SLAW.
Dal telefono sulla stessa Wi-Fi: `python server.py --lan`.
